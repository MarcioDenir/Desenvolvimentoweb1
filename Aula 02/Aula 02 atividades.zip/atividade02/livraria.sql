CREATE DATABASE biblioteca;

USE biblioteca;

CREATE TABLE livros(
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    autor VARCHAR(100) NOT NULL
);

SELECT*FROM livros;